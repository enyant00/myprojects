package com.ef;

/**
 * 
 * @author ngabu
 *
 */
public class Log {

	private String date;
	private String ip;
	private String reqeust;
	private String status;
	private String userAgent;
	
	public Log(String date, String ip, String reqeust, String status, String userAgent) {
		super();
		this.date = date;
		this.ip = ip;
		this.reqeust = reqeust;
		this.status = status;
		this.userAgent = userAgent;
	}

	@Override
	public String toString() {
		return "Log [Date=" + date + ", IP=" + ip + ", Reqeust=" + reqeust + ", Status=" + status
				+ ", UserAgent=" + userAgent + "]";
	}
}