package com.ef;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Set;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.GnuParser;
import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.ParseException;
import org.apache.commons.lang.StringUtils;

/**
 * 
 * @author Elias, 2018-10-15
 * 
 * Access Log Parser class
 *
 */
public class Parser {

	private static final String DB_CONNECTION = "jdbc:mysql://localhost:3306/accesslog";
	private static final String DB_USER = "root";
	private static final String DB_PASSWORD = "";

	private static void usage(PrintStream out, String[] args) {
		HelpFormatter hf = new HelpFormatter();
		hf.printHelp("LogParser", options());
		out.println("Your arguments were: " + StringUtils.join(args, ' '));
	}

	private static Options options() {
		Options options = new Options();
		options.addOption("s", "startDate", true, "The date when request starting. Ex, 2017-01-01.12:00:00");
		options.addOption("d", "duration", true, "The duration value. Take only \"hourly\", \"daily\"");
		options.addOption("t", "threshold", true, "The number of requests limit");
		return options;
	}

	private static CommandLine getCommandLine(PrintStream out, String[] args) {
		CommandLineParser clp = new GnuParser();
		CommandLine cl;
		try {
			cl = clp.parse(options(), args);
		} catch (ParseException e) {
			usage(out, args);
			return null;
		}

		if (cl.getOptions().length == 0) {
			usage(out, args);
			return null;
		}

		return cl;
	}

	@SuppressWarnings("resource")
	public static void main(String[] args) throws java.text.ParseException, SQLException {
		// TODO Auto-generated method stub

		PrintStream startupOut = System.out;
		CommandLine cl = getCommandLine(startupOut, args);
		if (cl == null) {
			// usage(startupOut, args);
			return;
		}

		Calendar cal = Calendar.getInstance();
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");

		// get parameter values from command line
		String sValue = cl.getOptionValue('s').toString().replace(".", " ");
		if (sValue.length() == 19)
			sValue += ".000";
		Date sDate = dateFormat.parse(sValue);
		cal.setTime(sDate);

		String duration = cl.getOptionValue('d').toString();
		if (duration.equals("hourly"))
			cal.add(Calendar.HOUR, 1);
		else
			cal.add(Calendar.DATE, 1);
		Date eDate = cal.getTime();

		int threshold = Integer.valueOf(cl.getOptionValue('t').toString());

		HashMap<String, List<Log>> logsGroupedByIp = new HashMap<String, List<Log>>();

		try {
			BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream(new File("access.log"))));
			String line = null;
			while ((line = in.readLine()) != null) {

				String date = line.substring(0, line.indexOf("|"));
				Date dt = dateFormat.parse(date);

				line = line.substring(line.indexOf("|") + 1);
				String ipAddress = line.substring(0, line.indexOf("|"));

				line = line.substring(line.indexOf("|") + 1);
				String request = line.substring(0, line.indexOf("|"));

				line = line.substring(line.indexOf("|") + 1);
				String status = line.substring(0, line.indexOf("|"));

				String userAgent = line.substring(line.indexOf("|") + 1);

				if (dt.after(sDate) && dt.before(eDate) || dt.equals(sDate) || dt.equals(eDate)) {
					String key = ipAddress;
					if (logsGroupedByIp.containsKey(key)) {
						logsGroupedByIp.get(key).add(new Log(date, ipAddress, request, status, userAgent));
					} else {
						List<Log> list = new ArrayList<Log>();
						list.add(new Log(date, ipAddress, request, status, userAgent));
						logsGroupedByIp.put(key, list);
					}
				}
			}
			
			// Database Connect
			Connection dbConnection = null;
			PreparedStatement preparedStatement = null;
			
			dbConnection = getDBConnection();
			try {
				
				// Get Max Value of PK_ID
				preparedStatement = dbConnection.prepareStatement("select max(PK_ID) from log_parse");
				ResultSet rs = preparedStatement.executeQuery();
				rs.next();
				int maxIdValue = rs.getInt(1);
				rs.close();

				Set<String> keySets = logsGroupedByIp.keySet();
				for (String key : keySets) {
					if (logsGroupedByIp.get(key).size() > threshold) {

						for (Log log : logsGroupedByIp.get(key)) {
							System.out.println(log.toString());
						}
						System.out.println();
						
						// If log already exist
						preparedStatement = dbConnection.prepareStatement("SELECT COUNT(*) from log_parse WHERE IPADDRESS=? and START_DATE=? and END_DATE=?");
						preparedStatement.setString(1, key);
						preparedStatement.setString(2, dateFormat.format(sDate));
						preparedStatement.setString(3, dateFormat.format(eDate));
						ResultSet rs1 = preparedStatement.executeQuery();
						rs1.next();
						int count = rs1.getInt(1);
						
						// if log not exist, then insert it into table
						if (count == 0) {
							
							preparedStatement = dbConnection.prepareStatement("INSERT INTO log_parse VALUES (?,?,?,?,?,?)");
							
							preparedStatement.setInt(1, ++maxIdValue);
							preparedStatement.setString(2, key);
							preparedStatement.setInt(3, logsGroupedByIp.get(key).size());
							preparedStatement.setString(4, dateFormat.format(sDate));
							preparedStatement.setString(5, dateFormat.format(eDate));
							preparedStatement.setString(6, "This ip has been blocked since it requested more than " + threshold + " within "
									+ duration);

							preparedStatement.executeUpdate();
						}
					}
				}
				
			} catch (SQLException e) {
				
			} finally {
				
				if (preparedStatement != null) {
					preparedStatement.close();
				}

				if (dbConnection != null) {
					dbConnection.close();
				}
			}
			
			in.close();
			System.out.println("Parsing has been completed successfully.");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Database Connection method
	 * 
	 * @return
	 */
	private static Connection getDBConnection() {

		Connection dbConnection = null;

//		try {
//
//			Class.forName(DB_DRIVER);
//
//		} catch (ClassNotFoundException e) {
//
//			System.out.println(e.getMessage());
//
//		}

		try {

			dbConnection = DriverManager.getConnection(DB_CONNECTION, DB_USER, DB_PASSWORD);
			return dbConnection;

		} catch (SQLException e) {

			System.out.println(e.getMessage());

		}

		return dbConnection;

	}
}