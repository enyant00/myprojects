package org.univocity.html.parser.demonstrate;

import java.io.File;
import java.util.List;
import java.util.Map;

import com.univocity.parsers.csv.Csv;
import com.univocity.parsers.csv.CsvWriter;
import com.univocity.parsers.csv.CsvWriterSettings;

public class CsvResultHelper {

	public static void saveResults(String parserName, List<Map<String, String>> results) {
		File resultFile = new File(System.getProperty("user.home") + "/" + parserName + ".csv");
		System.out.println(parserName + " captured " + results.size() + " records. Results saved to " + resultFile.getAbsolutePath());

		CsvWriterSettings settings = Csv.writeExcel();
		settings.setHeaders(results.get(0).keySet().toArray(new String[0]));
		settings.setHeaderWritingEnabled(true);
		settings.setNullValue("N/A");
		CsvWriter writer = new CsvWriter(resultFile, "windows-1252", settings);
		for (Map<String, String> record : results) {
			writer.writeRow(record);
		}
		writer.close();
	}
}
