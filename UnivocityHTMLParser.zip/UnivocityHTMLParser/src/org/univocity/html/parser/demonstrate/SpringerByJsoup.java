package org.univocity.html.parser.demonstrate;

import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.jsoup.Connection;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

/**
 * 
 * @author EL 2018-08-05
 * 
 */
public class SpringerByJsoup {

	public static void main(String... args) throws IOException {
		
		long startTime = System.currentTimeMillis();
		List<Map<String, String>> results = new SpringerByJsoup() .parse("https://jrenewables.springeropen.com/articles");
		System.out.println("Elapsed time: " + (System.currentTimeMillis() - startTime) + "ms");
		CsvResultHelper.saveResults("jsoup", results);
	}

	private List<Map<String, String>> results = new ArrayList<>();

	private List<Map<String, String>> parse(String sUrl) throws IOException {
		results.clear();
		Connection connection = Jsoup.connect(sUrl);
		
		Document doc = connection.get();

		Elements elements = doc.getElementsByClass("c-list-group__item");

		Map<String, String> record = new LinkedHashMap<>();
		results.add(record);

		for (Element element : elements) {
			if (element != null) {
				if (element.getElementsByClass("c-teaser__title").first() != null) {
					String title = element.getElementsByClass("c-teaser__title").first().text();
					record = addToRecord(record, "title", title);
				}
				if (element.getElementsByClass("c-teaser__title").first() != null) {
					String url = element.getElementsByClass("c-teaser__title").first().child(0).attr("abs:href");
					record = addToRecord(record, "url", url);
					
					// get article page
					Connection articleConnection = Jsoup.connect(url);					
					Document articleDoc = articleConnection.get();
					
					String articleAbstract = articleDoc.getElementById("Abstract").text();
					record = addToRecord(record, "abstract", articleAbstract);
					String articleKeyword = articleDoc.getElementsByClass("c-keywords").first().text();					
					record = addToRecord(record, "keywords", articleKeyword);
				}
				if (element.getElementsByClass("c-teaser__snippet").first() != null) {
					String snippet = element.getElementsByClass("c-teaser__snippet").first().text();
					record = addToRecord(record, "snippet", snippet);
				}
				if (element.getElementsByClass("c-teaser__authors").first() != null) {
					String authors = element.getElementsByClass("c-teaser__authors").first().text();
					record = addToRecord(record, "authors", authors);
				}
				if (element.getElementsByAttributeValue("itemprop", "datePublished").first() != null) {
					Element e = element.getElementsByAttributeValue("itemprop", "datePublished").first();
					String pubDate = e.text();
					record = addToRecord(record, "pubDate", pubDate);
					record = addToRecord(record, "year", pubDate.replaceAll("(.*)(\\d{4})", "$2"));
				}
				if (element.getElementsByClass("c-teaser__view-options").first() != null) {
					Element e = element.getElementsByClass("c-teaser__view-options").first();
					String pdfUrl = e.child(1).child(0).attr("href");
					record = addToRecord(record, "pdfUrl", pdfUrl);
				}				
				if (element.getElementsByClass("c-teaser__journal").first() != null) {
					record = addToRecord(record, "journalTitle", element.getElementsByClass("c-teaser__journal").first().text());
				}
				
				if (element.getElementsByClass("c-teaser__volume").first() != null) {
					record = addToRecord(record, "volume", element.getElementsByClass("c-teaser__volume").first().text());
				}
			}
		}	
		return results;
	}

	private Map<String, String> addToRecord(Map<String, String> record, String key, String value) {
		if (record.containsKey(key)) {
			record = new LinkedHashMap<>();
			results.add(record);
		}
		record.put(key, value);
		return record;
	}
}