package org.univocity.html.parser.demonstrate;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.univocity.api.entity.html.HtmlEntityList;
import com.univocity.api.entity.html.HtmlEntitySettings;
import com.univocity.api.entity.html.HtmlLinkFollower;
import com.univocity.api.entity.html.HtmlParser;
import com.univocity.api.entity.html.HtmlParserResult;
import com.univocity.api.entity.html.HtmlRecord;
import com.univocity.api.net.UrlReaderProvider;
import com.univocity.parsers.common.Nesting;
import com.univocity.parsers.common.Results;

public class SpringerByUnivocity {

	public static void main(String... args) {
		
		HtmlEntityList entityList = getMetadata();
		
		UrlReaderProvider urp = new UrlReaderProvider("https://jrenewables.springeropen.com/articles");
		HtmlParser parser = new HtmlParser(entityList);
		Results<HtmlParserResult> results = parser.parse(urp);
		HtmlParserResult itemResults = results.get("springer");
		List<Map<String, String>> tmp = new ArrayList<>();
		for(HtmlRecord record : itemResults.iterateRecords()) {
			tmp.add(record.fillFieldMap(new LinkedHashMap<String,String>()));
		}
		
		CsvResultHelper.saveResults("univocity", tmp);
	}

	/**
	 * Returns the links of all properties in the first page of results.
	 */
	public static HtmlEntityList getMetadata() {
		
		HtmlEntityList entityList = new HtmlEntityList();
		
		// Configure the "springer" entity. It handles the search results that list all springer available.
		HtmlEntitySettings springer = entityList.configureEntity("springer");
		springer.addField("title").match("li").classes("c-list-group__item").match("h3").match("a").getText();
		HtmlLinkFollower articleLink = springer.addField("url").match("li").classes("c-list-group__item").match("h3").match("a").getAttribute("abs:href").followLink();
		articleLink.addField("abstract").match("div").id("Abstract").getText();
		articleLink.addField("keywords").match("div").id("Keywords").getText();
		articleLink.setNesting(Nesting.JOIN);
		
		springer.addField("snippet").match("p").classes("c-teaser__snippet").getText();
		springer.addField("authors").match("p").classes("c-teaser__authors").getText();
		springer.addField("journalTitle").match("em").classes("c-teaser__journal").getText();
		springer.addField("year").match("span").classes("c-teaser__volume").getPrecedingText();
		springer.addField("volume").match("span").classes("c-teaser__volume").getText();
		springer.addField("pubDate").match("p").withText("Published on: ").match("span").getText();
		springer.addField("pdfUrl").match("ul").classes("c-teaser__view-options").matchLast("li").match("a").getAttribute("href");
		
		return entityList;
	}
}