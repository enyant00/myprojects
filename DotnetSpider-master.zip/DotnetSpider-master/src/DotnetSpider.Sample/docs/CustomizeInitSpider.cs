﻿//using DotnetSpider.Core;
//using DotnetSpider.Extension;
//using System;

//namespace DotnetSpider.Sample.docs
//{
//	[TaskName("CustomizeInitSpider")]
//	public class CustomizeInitSpider : CommonSpider
//	{
//		protected override void OnInit(params string[] arguments)
//		{
//			Identity = Guid.NewGuid().ToString("N");
//		}
//	}
//}
