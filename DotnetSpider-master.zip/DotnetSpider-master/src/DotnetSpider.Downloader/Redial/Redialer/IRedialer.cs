﻿namespace DotnetSpider.Downloader.Redial.Redialer
{
	/// <summary>
	/// 拨号器
	/// </summary>
	public interface IRedialer
	{
		/// <summary>
		/// 拨号
		/// </summary>
		void Redial();
	}
}
