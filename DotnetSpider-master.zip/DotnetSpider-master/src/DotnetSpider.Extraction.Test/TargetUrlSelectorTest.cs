﻿namespace DotnetSpider.Extension.Test.Model
{
	public class TargetUrlSelectorTest
	{

	}
}
