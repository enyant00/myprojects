﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DotnetSpider.Node
{
	public enum NodeStatus
	{
		Running,
		Stop,
		Exiting,
		Exited
	}
}
