﻿namespace DotnetSpider.Extension.Test.Pipeline
{
	public class ExcelEntityPipelineTest
	{

	}
}
