﻿namespace DotnetSpider.Extension
{
	//public class ConfigurableSpider : Spider
	//{
	//	private readonly string _json;

	//	public ConfigurableSpider(string json)
	//	{
	//		_json = json;
	//	}

	//	protected override void OnInit(params string[] arguments)
	//	{

	//	}
	//}
}
