﻿using DotnetSpider.Extraction.Model.Attribute;

namespace DotnetSpider.Extraction.Model
{
	public interface IBaseEntity
	{
	}
}
