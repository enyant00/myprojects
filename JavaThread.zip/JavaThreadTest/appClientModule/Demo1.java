import java.lang.management.ManagementFactory;
import java.lang.management.MemoryPoolMXBean;
import java.lang.management.MemoryUsage;
import java.lang.management.ThreadMXBean;
import java.util.List;

/*
 * Without Executor Code (with multithreading):
 */
public class Demo1 {

	public static void main(String arg[]) {
//	    Demo1 demo = new Demo1();
	    Thread t5  = new Thread(new Runnable() {
	       public void run() {
	              int count=0;
	              // Thread.State;
	              // System.out.println("ClientMsgReceiver started-----");
	              Demo1.ChildDemo  obj = new Demo1.ChildDemo();
	              while(true) {

	                // System.out.println("Threadcount is"+Thread);
	                // System.out.println("count is"+(count++));
	                Thread t=new Thread(obj);
	                t.start();
	                ThreadMXBean tb = ManagementFactory.getThreadMXBean();
	                List<MemoryPoolMXBean> pools = ManagementFactory.getMemoryPoolMXBeans();
	                for (MemoryPoolMXBean pool : pools) {
	                   MemoryUsage peak = pool.getPeakUsage();
	                   System.out.format("Peak %s memory used: %,d%n",
	                             pool.getName(), peak.getUsed());
	                   System.out.format("Peak %s memory reserved: %,d%n",
	                             pool.getName(), peak.getCommitted());
	                }

	                System.out.println("Current Thread Count"+ tb.getThreadCount());
	                System.out.println("Peak Thread Count"+ tb.getPeakThreadCount());
	                System.out.println("Current_Thread_Cpu_Time " + tb.getCurrentThreadCpuTime());
	                System.out.println("Daemon Thread Count" +tb.getDaemonThreadCount()); 
	       }
	       // ChatLogin = new ChatLogin();
	     }
	  });
	  t5.start();
}

static class ChildDemo implements Runnable {
	public void run() {
		try {
			// System.out.println("Thread Started with custom Run method");
			Thread.sleep(100000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			System.out.println("A" + Thread.activeCount());
		}
	}
}}
