import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MultiThreadExecutors2 implements Runnable {
	
	private int total;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ExecutorService executorService = Executors.newFixedThreadPool(6);
		MultiThreadExecutors2 runnable = new MultiThreadExecutors2();
		executorService.execute(runnable);
		executorService.execute(runnable);
		executorService.execute(runnable);
		executorService.execute(runnable);
		executorService.execute(runnable);
		executorService.execute(runnable);
		executorService.shutdown();
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		for (int i = 1; i <= 10; i++) {
			total += i;
		}
		System.out.printf("[%s] 1에서 20000까지의 총 합은 %d입니다.%n", Thread.currentThread().getName(), total);
	}
}