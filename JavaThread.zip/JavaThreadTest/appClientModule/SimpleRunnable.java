
public class SimpleRunnable implements Runnable {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Thread thread0 = new SimpleThread();
		Thread thread1 = new SimpleThread();
		
		thread0.start();
		thread1.start();
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		for (int i = 0; i < 10 ; i++) {
			System.out.printf("[%s] %d번째 실행입니다. %n", Thread.currentThread().getName(), i);
		}
	}
}