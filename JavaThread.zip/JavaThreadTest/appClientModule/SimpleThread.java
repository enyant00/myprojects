
public class SimpleThread extends Thread {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		Thread thread0 = new SimpleThread();
		Thread thread1 = new SimpleThread();
		
		thread0.start();
		thread1.start();
	}
	
	public void run() {
		for (int i = 0; i < 10 ; i++) {
			System.out.printf("[%s] %d번째 실행입니다. %n", Thread.currentThread().getName(), i);
		}
	}
}