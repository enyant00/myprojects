import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/**
 * 작업처리결과를 외부객체에 저장
 * @author Administrator
 *
 */
public class ResultByRunnableExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// 스레드풀 생성
		ExecutorService executorService = Executors.newFixedThreadPool(Runtime.getRuntime().availableProcessors());

		System.out.println("[작업 처리 요청]");

		Result result = new Result();
		Runnable task1 = new Task(result);
		Runnable task2 = new Task(result);

		// 스레드풀의 작업 큐에 저장
		Future<Result> future1 = executorService.submit(task1, result);
		Future<Result> future2 = executorService.submit(task2, result);

		try {
			result = future1.get();
			result = future2.get();
			System.out.println("[처리 결과] " + result.accumValue);
			System.out.println("[작업 처리 완료]");
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("[실행 예외 발생] " + e.getMessage());
		}
		executorService.shutdown(); // 작업 큐에 대기하고 있는 모든 작업을 처리한 뒤에 스레드풀을 종료
	}
}

class Task implements Runnable {
	Result result;

	public Task(Result result) {
		this.result = result;
	}

	@Override
	public void run() {
		int sum = 0;
		for (int i = 0; i <= 10; i++) {
			sum += i;
		}
		result.addValue(sum); // Result 객체에 작업 결과 저장
	}
}

class Result {
	int accumValue;

	synchronized void addValue(int value) {
		accumValue += value;
	}
}