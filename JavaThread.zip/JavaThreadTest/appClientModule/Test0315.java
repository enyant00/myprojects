
public class Test0315 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// ======================= ==========================
		Runnable test1 = new Thread1();
		Thread thread1 = new Thread(test1);
		thread1.start();
		
		
		// ======================= ==========================
		Thread thread2 = new Thread(new Runnable(){
			int sum2 = 0;
			@Override
			public void run() {
				// TODO Auto-generated method stub
				for (int i = 1; i <= 10; i++) {
					sum2 += i;
				}
				System.out.println("sum2: " + sum2);
			}
			
		});
		thread2.start();
		
		
		// ======================= ==========================
		Thread thread3 = new Thread(()->{
			// code
			int sum3 = 0;
			for (int i = 1; i <= 10; i++) {
				sum3 += i;
			}
			System.out.println("sum3: " + sum3);
		});
		thread3.start();
		
		
		// ======================= ==========================
		Thread thread4 = new Thread2();
		thread4.start();
		
		
		// ======================= ==========================
		Thread thread5 = new Thread() {
			int sum5 = 0;
			@Override
		    public void run(){
		        // 스레드가 실행할 코드
				for (int i = 1; i <= 10; i++) {
					sum5 += i;
				}
				System.out.println("sum5: " + sum5);
		    }

		};
		thread5.start();
		
		
		// ====================== ===========================
	}
}

class Thread1 implements Runnable {
	int sum1 = 0;
	@Override
	public void run() {
		// TODO Auto-generated method stub
		for (int i = 1; i <= 10; i++) {
			sum1 += i;
		}
		System.out.println("sum1: " + sum1);
	}	
}

class Thread2 extends Thread {
	int sum4 = 0;
	@Override
	public void run() {
		// TODO Auto-generated method stub
		for (int i = 1; i <= 10; i++) {
			sum4 += i;
		}
		System.out.println("sum4: " + sum4);
	}
}