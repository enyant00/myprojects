import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/**
 * 리턴값이 있는 작업완료통보
 * @author Administrator
 *
 */
public class ResultByCallableExample {

	public static void main(String[] args) {
		// 스레드풀 생성
		ExecutorService executorService = Executors.newFixedThreadPool(Runtime.getRuntime().availableProcessors());

		System.out.println("[작업 처리 요청]");

		Callable<Long> callable = new Callable<Long>() {
			@Override
			public Long call() throws Exception {
				long sum = 0;
				for (long i = 1; i <= 10; i++) {
					sum += i;
				}

				return sum;
			}
		};

		Future<Long> future = executorService.submit(callable);

		try {
			long sum = future.get();
			System.out.println("[처리 결과] " + sum);
			System.out.println("[작업 처리 완료]");
		} catch (Exception e) {
			System.out.println("[실행 예외 발생] " + e.getMessage());
		}

		executorService.shutdown(); // 작업 큐에 대기하고 있는 모든 작업을 처리한 뒤에 스레드풀을 종료

	}
}