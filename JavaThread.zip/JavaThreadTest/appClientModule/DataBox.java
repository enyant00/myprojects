public class DataBox {
	private String data;
	
	public static void main(String[] args) throws InterruptedException{
        DataBox dataBox = new DataBox();

        ProducerThread producerThread = new ProducerThread(dataBox);
        Thread.sleep(1000);
        ConsumerThread consumerThread = new ConsumerThread(dataBox);

        producerThread.start();
        consumerThread.start();
    }

	public synchronized String getData() {
		if (this.data == null) {
			try {
				wait(); // data가 null인 경우, 스레드를 일시 정지 상태로 만든다.
			} catch (InterruptedException e) {
				// ...
			}
		}

		String returnValue = data;
		System.out.println("ConsumerThread가 읽은 데이터 : " + returnValue);

		data = null;
		notify(); // ProducerThread를 실행 대기 상태로 만듬
		return returnValue;
	}

	public synchronized void setData(String data) {
		if (this.data != null) {
			try {
				wait(); // data가 null이 아니면, 스레드를 일시 정지 상태로 만든다.
			} catch (InterruptedException e) {
				// ...
			}
		}

		this.data = data;
		System.out.println("ProducerThread가 생성한 데이터 : " + data);
		notify(); // wait()에 의해서 일시 정지된 Thread를 실행 대기 상태로 만듬
	}
}

class ProducerThread extends Thread{
    private DataBox dataBox;

    public ProducerThread(DataBox dataBox){
        this.dataBox = dataBox;
    }

    @Override
    public void run(){
        for(int i=1; i<=5; i++){
            String data = "Data - "+ i;
            dataBox.setData(data);
        }
    }
}

class ConsumerThread extends Thread{
    private DataBox dataBox;

    public ConsumerThread(DataBox dataBox){
        this.dataBox = dataBox;
    }

    @Override
    public void run(){
        for(int i=1; i<=5; i++){
            String data = dataBox.getData();
        }
    }
}
