
public class YieldExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ThreadA threadA = new ThreadA();
        ThreadB threadB = new ThreadB();

        // ThreadA, ThreadB 모두 실행
        threadA.start();
        threadB.start();

        try{
            Thread.sleep(3000);
        }catch(InterruptedException e){
            // ...    
        }
        threadA.work = false;       // ThreadB만 실행

        try{
            Thread.sleep(3000);
        }catch(InterruptedException e){
            // ...    
        }
        threadA.work = true;        // ThreadA, ThreadB 모두 실행

        try{
            Thread.sleep(3000);
        }catch(InterruptedException e){
            // ...    
        }
        threadA.stop = true;        // ThreadA, ThreadB 모두 종료
        threadB.stop = true;
	}
}

class ThreadA extends Thread {

	public boolean stop = false;    // 종료 플래그
    public boolean work = true; // 작업 진행 여부 플래그

    public void run(){
        while(!stop){
            if(work){
                // 작업 내용
            	System.out.println("ThreadA 작업진행중");
            }else{            	
                Thread.yield(); // work가 false가 되면, 다른 스레드에게 실행을 양보
            }
        }
        System.out.println("ThreadA 종료");
    }

}

class ThreadB extends Thread {
	public boolean stop = false;    // 종료 플래그
    public boolean work = true; // 작업 진행 여부 플래그

    public void run(){
        while(!stop){
            if(work){
                // 작업 내용
            	System.out.println("ThreadB 작업진행중");
            }else{
            	System.out.println("ThreadA에게 실행 양보");
                Thread.yield(); // work가 false가 되면, 다른 스레드에게 실행을 양보
            }
        }
        System.out.println("ThreadB 종료");
    }
}