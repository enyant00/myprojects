import java.lang.management.ManagementFactory;
import java.lang.management.MemoryPoolMXBean;
import java.lang.management.MemoryUsage;
import java.lang.management.ThreadMXBean;
import java.util.List;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/*
 * With executor (multithreading):
 */
public class Executor_Demo {
	public static void main(String arg[]) {
		BlockingQueue<Runnable> queue = new ArrayBlockingQueue<Runnable>(10);
		ThreadPoolExecutor executor = new ThreadPoolExecutor(10, 100, 10, TimeUnit.MICROSECONDS, queue);
//		Executor_Demo demo = new Executor_Demo();

		executor.execute(new Runnable() {
			public void run() {
//				int count = 0;
				// System.out.println("ClientMsgReceiver started-----");
//				Executor_Demo.Demo demo2 = new Executor_Demo.Demo();
				BlockingQueue<Runnable> queue1 = new ArrayBlockingQueue<Runnable>(100);
				ThreadPoolExecutor executor1 = new ThreadPoolExecutor(1000, 10000, 10, TimeUnit.MICROSECONDS, queue1);

				while (true) {
					// System.out.println("Threadcount is"+Thread);
					// System.out.println("count is"+(count++));
					Runnable command = new Demo();
					// executor1.execute(command);
					executor1.submit(command);
					// Thread t=new Thread(demo2);
					// t.start();
					ThreadMXBean tb = ManagementFactory.getThreadMXBean();
					/*
					 * try { executor1.awaitTermination(100,
					 * TimeUnit.MICROSECONDS); } catch (InterruptedException e)
					 * { // TODO Auto-generated catch block e.printStackTrace();
					 * }
					 */
					List<MemoryPoolMXBean> pools = ManagementFactory.getMemoryPoolMXBeans();
					for (MemoryPoolMXBean pool : pools) {
						MemoryUsage peak = pool.getPeakUsage();
						System.out.format("Peak %s memory used: %,d%n", pool.getName(), peak.getUsed());
						System.out.format("Peak %s memory reserved: %,d%n", pool.getName(), peak.getCommitted());
					}
					System.out.println("daemon threads" + tb.getDaemonThreadCount());
					System.out.println("All threads" + tb.getAllThreadIds());
					System.out.println("current thread CPU time " + tb.getCurrentThreadCpuTime());
					System.out.println("current thread user time " + tb.getCurrentThreadUserTime());
					System.out.println("Total started thread count " + tb.getTotalStartedThreadCount());
					System.out.println("Current Thread Count" + tb.getThreadCount());
					System.out.println("Peak Thread Count" + tb.getPeakThreadCount());
					System.out.println("Current_Thread_Cpu_Time " + tb.getCurrentThreadCpuTime());
					System.out.println("Daemon Thread Count" + tb.getDaemonThreadCount());
//					executor1.shutdown();
				}
				// ChatLogin = new ChatLogin();
			}
		});
		executor.shutdown();
	}

	static class Demo implements Runnable {
		public void run() {
			try {
				// System.out.println("Thread Started with custom Run method");
				Thread.sleep(10000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} finally {
				System.out.println("A" + Thread.activeCount());
			}
		}
	}
}