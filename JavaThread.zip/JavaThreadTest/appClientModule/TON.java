
public class TON {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int sum = 0;
        for(int i=1; i<=1000000; i++){
            sum += i;
        }
        System.out.println("[처리 결과] " + sum);
	}
}