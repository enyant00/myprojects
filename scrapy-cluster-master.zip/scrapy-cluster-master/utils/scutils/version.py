__version__ = '1.2.0'
VERSION = tuple(int(x) for x in __version__.split('.'))
