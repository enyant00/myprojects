STRING = "stuff"
DICT = {
    "value": "other stuff"
}
