from __future__ import unicode_literals
from settings.base_settings import *


DSCRAPER_CUSTOM_PROCESSORS = [
    'scraper.utils.custom_processors',
]