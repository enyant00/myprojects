from __future__ import unicode_literals
from settings.base_settings import *


IMAGES_THUMBS = {
    'medium': (50, 50),
    'small': (25, 25),
}

DSCRAPER_IMAGES_STORE_FORMAT = 'THUMBS'