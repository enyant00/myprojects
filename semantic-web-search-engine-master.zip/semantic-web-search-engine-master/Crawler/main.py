from Crawler import Crawler

g = Crawler("http://dbpedia.org/resource/George_W._Bush")


