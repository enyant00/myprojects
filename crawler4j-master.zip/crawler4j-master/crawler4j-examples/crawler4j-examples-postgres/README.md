A sample shows how to save crawled page into a JDBC repository.

Shamelessy grabbed with rzo1's permission, from [the original repo](https://github.com/rzo1/crawler4j-postgres-sample).