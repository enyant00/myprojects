package org.solr.index.ashclinical;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.net.ssl.HttpsURLConnection;

import org.apache.solr.client.solrj.SolrClient;
import org.apache.solr.client.solrj.SolrServerException;
import org.apache.solr.client.solrj.impl.HttpSolrClient;
import org.apache.solr.common.SolrInputDocument;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
 
import org.xml.sax.SAXException;

/**
 * 
 * @author elias, 2018-09-18
 *
 */
public class MedCalc {

	private static String solrServerUrl = "http://localhost:8983/solr/docs";
	
	private static final String USER_AGENT = "Mozilla/5.0 (Windows NT 6.2; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/49.0.2623.110 Safari/537.36";

	private List<String> cookies;
	private HttpsURLConnection conn;
	/**
	 * 
	 * @param args
	 * @throws IOException
	 * @throws SAXException
	 * @throws SolrServerException
	 */
	public static void main(String[] args) throws IOException, SAXException, SolrServerException {
		// TODO Auto-generated method stub
		
		MedCalc mainClass = new MedCalc();
		String html = mainClass.GetPageContent("https://www.mdcalc.com/#all");
					
		Document doc = Jsoup.parse(html);

		Elements els = doc.selectFirst("div.azNav").nextElementSibling().select("li.calc-item");
		for (Element el : els) {
			String link = el.getElementsByClass("index_all_calcItem").first().attr("href");
			System.out.println(link);
			
			Document detailDoc = Jsoup.connect("https://www.mdcalc.com" + link).get();
			
			Element calcHeaer = detailDoc.selectFirst("div.calc__header");
			System.out.println(calcHeaer.selectFirst("h1.calc__title").text());
			System.out.println(calcHeaer.selectFirst("div.calc__desc").text());
			
			Element topContent = detailDoc.selectFirst("div.top-content");
			Elements els1 = topContent.getElementsByClass("notice is-active");
			Iterator iter = els1.iterator(); 
			while (iter.hasNext()) {
				Element e = (Element) iter.next();
				
				if(e.attr("data-content").equals("use-cases"))
					System.out.println("use-cases:" + e.text());
				
				else if (e.attr("data-content").equals("pearls-pitfalls"))
					System.out.println("pearls-pitfalls:" + e.text());
				
				else
					System.out.println("why-use:" + e.text());
			}
			
			Element inputEl = detailDoc.selectFirst("div.inputs");
			Elements inputs = inputEl.select("div.input");
			Iterator iter1 = inputs.iterator();
			while (iter1.hasNext()) {
				Element e = (Element) iter1.next();
				System.out.println("label:" + e.select("div.input__label-wrapper").text());
				System.out.println("detail:" + e.select("div.input__control-wrapper").text());
			}
			
			
			Element mainContent = detailDoc.selectFirst("div.main-column");
			Elements els2 = mainContent.getElementsByClass("notice is-active");
			Iterator iter2 = els2.iterator(); 
			while (iter2.hasNext()) {
				Element e = (Element) iter2.next();
				
				if(e.attr("data-content").equals("next-steps"))
					System.out.println("next-steps:" + e.text());
				
				else if (e.attr("data-content").equals("evidence"))
					System.out.println("evidence:" + e.text());
				
				else if (e.attr("data-content").equals("creator-insights")) {
					System.out.println("creator-insights:" + e.text());
					Element e1 = e.selectFirst("div.resource--author");
					String img = e1.selectFirst("img").attr("src");
					String author = e1.selectFirst("div.resource__text").text();
					String author_desc = e1.nextElementSibling().text();
				}
			}
			
			Element side = detailDoc.selectFirst("div.side-column");
			System.out.println("related_calcs:" + side.selectFirst("dd.rr-header-container").nextElementSibling().text().replaceAll("Related Calcs", ""));
			
			System.out.println("Completed!...");
			
		}
	}
	
	private String sendPost(String url, String postParams) throws Exception {

		URL obj = new URL(url);
		conn = (HttpsURLConnection) obj.openConnection();

		// Acts like a browser
		conn.setUseCaches(false);
		conn.setRequestMethod("POST");
		conn.setRequestProperty("Host", "accounts.google.com");
		conn.setRequestProperty("User-Agent", USER_AGENT);
		conn.setRequestProperty("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8");
		conn.setRequestProperty("Accept-Language", "en-US,en;q=0.5");
		for (String cookie : this.cookies) {
			conn.addRequestProperty("Cookie", cookie.split(";", 1)[0]);
		}
		conn.setRequestProperty("Connection", "keep-alive");
		conn.setRequestProperty("Referer", "https://accounts.google.com/ServiceLoginAuth");
		conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
		conn.setRequestProperty("Content-Length", Integer.toString(postParams.length()));

		conn.setDoOutput(true);
		conn.setDoInput(true);

		// Send post request
		DataOutputStream wr = new DataOutputStream(conn.getOutputStream());
		wr.writeBytes(postParams);
		wr.flush();
		wr.close();

		int responseCode = conn.getResponseCode();
		System.out.println("\nSending 'POST' request to URL : " + url);
		System.out.println("Post parameters : " + postParams);
		System.out.println("Response Code : " + responseCode);

		BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
		String inputLine;
		StringBuffer response = new StringBuffer();

		while ((inputLine = in.readLine()) != null) {
			response.append(inputLine);
		}
		in.close();
		return response.toString();
	}

	private String GetPageContent(String url) throws IOException {

		URL obj = new URL(url);
		conn = (HttpsURLConnection) obj.openConnection();

		// default is GET
		conn.setRequestMethod("GET");

		conn.setUseCaches(false);

		// act like a browser
		conn.setRequestProperty("User-Agent", USER_AGENT);
		conn.setRequestProperty("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8");
		conn.setRequestProperty("Accept-Language", "en,ko;q=0.8,zh-CN;q=0.6,zh;q=0.4");
		if (cookies != null) {
			for (String cookie : this.cookies) {
				conn.addRequestProperty("Cookie", cookie.split(";", 1)[0]);
			}
		}
		int responseCode = conn.getResponseCode();
//		System.out.println("\nSending 'GET' request to URL : " + url);
//		System.out.println("Response Code : " + responseCode);
		
		if(responseCode == 404) {
			
			try (FileWriter fw = new FileWriter("404.txt", true);
					BufferedWriter bw = new BufferedWriter(fw);
				    PrintWriter out = new PrintWriter(bw)) {
			    out.println(url);
			}
			return null;
		}

		BufferedReader in;
		try {
			in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
			
			String inputLine;
			StringBuffer response = new StringBuffer();

			while ((inputLine = in.readLine()) != null) {
				response.append(inputLine);
			}
			in.close();

			// Get the response cookies
			setCookies(conn.getHeaderFields().get("Set-Cookie"));

			return response.toString();
		} catch (IOException e) {
			// TODO Auto-generated catch block
//			e.printStackTrace();
			return null;
		}
	}

	public String getFormParams(String html, String keyword, String city) throws UnsupportedEncodingException {

		System.out.println("Extracting form's data...");

		Document doc = Jsoup.parse(html);

		// Google form id
		Element loginform = doc.getElementById("searh-box");
		Elements inputElements = loginform.getElementsByTag("input");
		List<String> paramList = new ArrayList<String>();
		for (Element inputElement : inputElements) {
			String key = inputElement.attr("name");
			String value = inputElement.attr("value");

			if (key.equals("what"))
				value = keyword;
			else if (key.equals("where"))
				value = city;
			paramList.add(key + "=" + URLEncoder.encode(value, "UTF-8"));
		}

		// build parameters list
		StringBuilder result = new StringBuilder();
		for (String param : paramList) {
			if (result.length() == 0) {
				result.append(param);
			} else {
				result.append("&" + param);
			}
		}
		return result.toString();
	}
	

	public List<String> getCookies() {
		return cookies;
	}

	public void setCookies(List<String> cookies) {
		this.cookies = cookies;
	}
}