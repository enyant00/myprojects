package org.solr.index.ashclinical;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

import javax.net.ssl.HttpsURLConnection;

import org.apache.solr.client.solrj.SolrClient;
import org.apache.solr.client.solrj.SolrServerException;
import org.apache.solr.client.solrj.impl.HttpSolrClient;
import org.apache.solr.common.SolrInputDocument;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
 
import org.xml.sax.SAXException;

/**
 * 
 * @author elias, 2018-09-18
 *
 */
public class Main {

	private static String solrServerUrl = "http://localhost:8983/solr/docs";
	
	private static final String USER_AGENT = "Mozilla/5.0 (Windows NT 6.2; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/49.0.2623.110 Safari/537.36";

	private List<String> cookies;
	private HttpsURLConnection conn;
	/**
	 * 
	 * @param args
	 * @throws IOException
	 * @throws SAXException
	 * @throws SolrServerException
	 */
	public static void main(String[] args) throws IOException, SAXException, SolrServerException {
		// TODO Auto-generated method stub
		
		System.out.println("Please enter the site url.");

		InputStreamReader isr = null;
		BufferedReader br = null;

		isr = new InputStreamReader(System.in);
		br = new BufferedReader(isr);
		
		String inputUrl = br.readLine();

		SolrClient solrClient = new HttpSolrClient.Builder(solrServerUrl).build();

		
		Main mainClass = new Main();
		String html = mainClass.GetPageContent(inputUrl);
		
		while (html != null) {
			
			Document doc = Jsoup.parse(html);
			
			Elements els = doc.getElementsByClass("td_module_16 td_module_wrap td-animation-stack");
			for (Element el : els) {
				String title = "", url = "", description = "", cluster_type = "", creation_date = "";
				String sublink = el.getElementsByClass("entry-title td-module-title").first().getElementsByTag("a").attr("href");
				String subHtml = mainClass.GetPageContent(sublink);
				
				Document subDoc = Jsoup.parse(subHtml);
				
				Element category = subDoc.selectFirst("ul.td-category");
				Elements list = category.select("li.entry-category");
				for(Element e : list) {
					cluster_type += e.text() + ", ";
				}
				cluster_type = cluster_type.substring(0, cluster_type.lastIndexOf(","));
				Element header = subDoc.selectFirst("header.td-post-title");
				title = header.selectFirst("h1.entry-title").text();
				creation_date = header.getElementsByClass("entry-date updated td-module-date").text();
				description = subDoc.getElementsByClass("td-post-content").first().text();
				
				// Preparing the Solr document
				SolrInputDocument solrDoc = new SolrInputDocument();

				// Adding fields to the document
				solrDoc.addField("title", title);
				solrDoc.addField("url", sublink);
				solrDoc.addField("creation_date", creation_date);
				solrDoc.addField("description", description);
				solrDoc.addField("cluster_type", cluster_type);

				// Adding the document to Solr
				solrClient.add(solrDoc);
			}
			html = null;
			if (doc.select("i.td-icon-menu-right").size() > 0) {
				if(doc.getElementsByClass("page-nav td-pb-padding-side").size() > 0) {
					if(doc.getElementsByClass("page-nav td-pb-padding-side").first().getElementsByClass("td-icon-menu-right").size() > 0) {
						Element paging = doc.getElementsByClass("page-nav td-pb-padding-side").first().getElementsByClass("td-icon-menu-right").first().parent();
						String pageUrl = paging.attr("href");
						html = mainClass.GetPageContent(paging.attr("href"));
					}
				}
			}
		}
		
		System.out.println("Commiting...");

		// Saving the changes
		solrClient.commit();

		System.out.println("Completed!...");
	}
	
	private String sendPost(String url, String postParams) throws Exception {

		URL obj = new URL(url);
		conn = (HttpsURLConnection) obj.openConnection();

		// Acts like a browser
		conn.setUseCaches(false);
		conn.setRequestMethod("POST");
		conn.setRequestProperty("Host", "accounts.google.com");
		conn.setRequestProperty("User-Agent", USER_AGENT);
		conn.setRequestProperty("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8");
		conn.setRequestProperty("Accept-Language", "en-US,en;q=0.5");
		for (String cookie : this.cookies) {
			conn.addRequestProperty("Cookie", cookie.split(";", 1)[0]);
		}
		conn.setRequestProperty("Connection", "keep-alive");
		conn.setRequestProperty("Referer", "https://accounts.google.com/ServiceLoginAuth");
		conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
		conn.setRequestProperty("Content-Length", Integer.toString(postParams.length()));

		conn.setDoOutput(true);
		conn.setDoInput(true);

		// Send post request
		DataOutputStream wr = new DataOutputStream(conn.getOutputStream());
		wr.writeBytes(postParams);
		wr.flush();
		wr.close();

		int responseCode = conn.getResponseCode();
		System.out.println("\nSending 'POST' request to URL : " + url);
		System.out.println("Post parameters : " + postParams);
		System.out.println("Response Code : " + responseCode);

		BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
		String inputLine;
		StringBuffer response = new StringBuffer();

		while ((inputLine = in.readLine()) != null) {
			response.append(inputLine);
		}
		in.close();
		return response.toString();
	}

	private String GetPageContent(String url) throws IOException {

		URL obj = new URL(url);
		conn = (HttpsURLConnection) obj.openConnection();

		// default is GET
		conn.setRequestMethod("GET");

		conn.setUseCaches(false);

		// act like a browser
		conn.setRequestProperty("User-Agent", USER_AGENT);
		conn.setRequestProperty("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8");
		conn.setRequestProperty("Accept-Language", "en,ko;q=0.8,zh-CN;q=0.6,zh;q=0.4");
		if (cookies != null) {
			for (String cookie : this.cookies) {
				conn.addRequestProperty("Cookie", cookie.split(";", 1)[0]);
			}
		}
		int responseCode = conn.getResponseCode();
		System.out.println("\nSending 'GET' request to URL : " + url);
		System.out.println("Response Code : " + responseCode);
		
		if(responseCode == 404) {
			
			try (FileWriter fw = new FileWriter("404.txt", true);
					BufferedWriter bw = new BufferedWriter(fw);
				    PrintWriter out = new PrintWriter(bw)) {
			    out.println(url);
			}
			return null;
		}

		BufferedReader in;
		try {
			in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
			
			String inputLine;
			StringBuffer response = new StringBuffer();

			while ((inputLine = in.readLine()) != null) {
				response.append(inputLine);
			}
			in.close();

			// Get the response cookies
			setCookies(conn.getHeaderFields().get("Set-Cookie"));

			return response.toString();
		} catch (IOException e) {
			// TODO Auto-generated catch block
//			e.printStackTrace();
			return null;
		}
	}

	public String getFormParams(String html, String keyword, String city) throws UnsupportedEncodingException {

		System.out.println("Extracting form's data...");

		Document doc = Jsoup.parse(html);

		// Google form id
		Element loginform = doc.getElementById("searh-box");
		Elements inputElements = loginform.getElementsByTag("input");
		List<String> paramList = new ArrayList<String>();
		for (Element inputElement : inputElements) {
			String key = inputElement.attr("name");
			String value = inputElement.attr("value");

			if (key.equals("what"))
				value = keyword;
			else if (key.equals("where"))
				value = city;
			paramList.add(key + "=" + URLEncoder.encode(value, "UTF-8"));
		}

		// build parameters list
		StringBuilder result = new StringBuilder();
		for (String param : paramList) {
			if (result.length() == 0) {
				result.append(param);
			} else {
				result.append("&" + param);
			}
		}
		return result.toString();
	}
	

	public List<String> getCookies() {
		return cookies;
	}

	public void setCookies(List<String> cookies) {
		this.cookies = cookies;
	}
}