#!/usr/bin/python
#-*-coding:utf-8-*-

"""
    This package is most from https://github.com/darkrho/scrapy-redis
    
    Use this to complete a distribute crawler with scrapy.I keep the infomation
    (request,stats)in redis,so the project in every machine can get and update it.
"""

