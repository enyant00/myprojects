#define MODE_MINIX2 1
#define MODE_BIGENDIAN 1
#include "minix.c"
