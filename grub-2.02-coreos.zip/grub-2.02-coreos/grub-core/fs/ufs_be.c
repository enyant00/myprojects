#define MODE_BIGENDIAN 1
#include "ufs.c"
