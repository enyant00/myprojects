#define MODE_MINIX3 1
#include "minix.c"
