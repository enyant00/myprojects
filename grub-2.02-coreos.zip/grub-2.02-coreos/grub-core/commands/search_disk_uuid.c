#define DO_SEARCH_DISK_UUID 1
#define FUNC_NAME grub_search_disk_uuid
#define COMMAND_NAME "search.disk_uuid"
#define HELP_MESSAGE N_("Search devices by disk UUID. If VARIABLE is specified, the first device found is set to a variable.")
#include "search.c"
