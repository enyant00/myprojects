package org.wk.main;

import java.io.IOException;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.jsoup.Jsoup;

/**
 * 
 * @author emmanuel
 * 
 *         2018-07-30, socket test java code
 * 
 *
 */
public class Client {

	public static void main(String args[]) {
		TimerTask tasknew = new CustomTask("http://64.137.161.165:18397/now");
		Timer timer = new Timer();
		timer.schedule(tasknew, 100, 100);
	}
}

class CustomTask extends TimerTask {

	private String url;

	// constructor to put ip address and port
	public CustomTask(String url) {
		this.url = url;
	}

	public void run() {
		String html, current;
		try {
			html = Jsoup.connect(url).get().html();
			current = extractTime(html);
			if (!current.isEmpty())
				System.out.println(current);

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public String extractTime(String html) {

		if (html == null)
			return "";
		html = html.replaceAll("[\\r\\n]", "");

		String regex = "(.*?)<td>Time</td>\\s*<td>(\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2}\\.\\d{3})</td>\\s*</tr>(.*?)";
		Pattern pattern = Pattern.compile(regex);
		Matcher matcher = pattern.matcher(html);
		String currentTime = "";
		if (matcher.find()) {
			currentTime = matcher.group(2).toString();
			if (currentTime.substring(currentTime.lastIndexOf(".") + 1).startsWith("0")) {
				return currentTime;
			}
		}

		return "";
	}
}
