package org.wk.main;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.Test;

public class TestTable {

	/**
	 * In case
	 * <td>Time</td>....<td>Time Fake</td>...
	 */
	@Test
	public void  testExtactAfteTime()
	{
		String html = "<!DOCTYPE html>\r\n" + 
				"<html lang=\"en\">\r\n" + 
				"<head>\r\n" + 
				"    <meta charset=\"UTF-8\"/>\r\n" + 
				"    <title>Current time</title>\r\n" + 
				"</head>\r\n" + 
				"<body>\r\n" + 
				"<h1>Current Time</h1>\r\n" + 
				"<table>\r\n" + 
				"    <tr>\r\n" + 
				"        <td>Time Fake</td>\r\n" + 
				"        <td>2018-07-31T18:41:11.519</td>\r\n" + 
				"    </tr>\r\n" + 
				"    <tr>\r\n" + 
				"        <td>Time</td>\r\n" + 
				"        <td>2018-07-30T18:41:11.016</td>\r\n" + 
				"    </tr>\r\n" + 
				"    <tr>\r\n" + 
				"        <td>IP Address</td>\r\n" + 
				"        <td>74.117.171.251</td>\r\n" + 
				"    </tr>\r\n" + 
				"</table>\r\n" + 
				"<p>\r\n" + 
				"    The user agent is <span>Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36</span>\r\n" + 
				"</p>\r\n" + 
				"</body>\r\n" + 
				"</html>";
		CustomTask ct = new CustomTask("");
		String currentTime = ct.extractTime(html);
		assertEquals("2018-07-30T18:41:11.016", currentTime);
	}
	
	/**
	 * In case
	 * <td>Time Fake</td>....<td>Time</td>...
	 */
	@Test
	public void  testExtactBeforeTime()
	{
		String html = "<!DOCTYPE html>\r\n" + 
				"<html lang=\"en\">\r\n" + 
				"<head>\r\n" + 
				"    <meta charset=\"UTF-8\"/>\r\n" + 
				"    <title>Current time</title>\r\n" + 
				"</head>\r\n" + 
				"<body>\r\n" + 
				"<h1>Current Time</h1>\r\n" + 
				"<table>\r\n" + 
				"    <tr>\r\n" + 
				"        <td>Time</td>\r\n" + 
				"        <td>2018-07-31T18:41:11.019</td>\r\n" + 
				"    </tr>\r\n" + 
				"    <tr>\r\n" + 
				"        <td>Time Fake</td>\r\n" + 
				"        <td>2018-07-30T18:41:11.216</td>\r\n" + 
				"    </tr>\r\n" + 
				"    <tr>\r\n" + 
				"        <td>IP Address</td>\r\n" + 
				"        <td>74.117.171.251</td>\r\n" + 
				"    </tr>\r\n" + 
				"</table>\r\n" + 
				"<p>\r\n" + 
				"    The user agent is <span>Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36</span>\r\n" + 
				"</p>\r\n" + 
				"</body>\r\n" + 
				"</html>";
		CustomTask ct = new CustomTask("");
		String currentTime = ct.extractTime(html);
		assertEquals("2018-07-31T18:41:11.019", currentTime);
	}
}
